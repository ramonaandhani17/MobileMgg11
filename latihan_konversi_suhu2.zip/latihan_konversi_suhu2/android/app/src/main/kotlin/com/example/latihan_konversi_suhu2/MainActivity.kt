package com.example.latihan_konversi_suhu2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
